Migration to v15
================

Despite the breaking changes in this release, most users should be able to
upgrade without problems. The public parser API is compatible with v14,
including both `new MarkdownIt()` and the `markdownit()` factory form.


## For users

Code that imports the package root and uses the public API should require no
changes.

All plugins from the
[`markdown-it` organization](https://github.com/markdown-it) are compatible
with v15. For third-party plugins, ask the plugin author whether v15 is
supported.

### Linkification

`linkify-it` no longer recognizes fuzzy links such as `example.com` by
default. If you rely on this behavior, enable it explicitly:

```js
const md = new MarkdownIt({ linkify: true })
md.linkify.set({ fuzzyLink: true })
```

### TypeScript types

Types are now bundled. Remove `@types/markdown-it` if you used it.


### Browser builds

Browser exports and bundle paths have changed. See
<https://unpkg.com/markdown-it/> for the current `dist/` contents and update
direct CDN URLs accordingly.


## For plugin developers

### Removed utilities

Three legacy helpers were removed from `md.utils`:

- `md.utils.assign()` — use `Object.assign()`.
- `md.utils.has(object, key)` — use
  `Object.prototype.hasOwnProperty.call(object, key)`.
- `md.utils.isString()` — use `typeof value === 'string'`.


### Package internals

Package-internal imports such as `markdown-it/lib/token.mjs` are no longer
exported. Common parser classes are available as static properties on the main
export:

```js
import MarkdownIt from 'markdown-it'

const Token = MarkdownIt.Token
const StateBlock = MarkdownIt.StateBlock
```

The same applies to `Ruler`, `Renderer`, `ParserCore`, `StateCore`,
`ParserBlock`, `ParserInline` and `StateInline`. Utilities and helpers remain
available on parser instances as `md.utils` and `md.helpers`. Individual rules
and presets are no longer exported.
